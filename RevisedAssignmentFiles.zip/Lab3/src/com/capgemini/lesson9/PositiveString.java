package com.capgemini.lesson9;

import java.util.Scanner;

public class PositiveString {

	private static Scanner scan;

	public static void main(String[] args) 
	{
		string str=new string();
		boolean f;
		f=str.positiveString();
		if(f==true)
		{
			System.out.println("Positive string");
		}
		else
		{
			System.out.println("Negative string");
		}
}
}
