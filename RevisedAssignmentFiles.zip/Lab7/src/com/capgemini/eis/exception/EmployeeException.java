package com.capgemini.eis.exception;

public class EmployeeException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeException() 
	{
		
	}
	public String toString() 
	{
		return "The Salary is below three thousand.";
	}

	public static  void checkEmp(double f)
	{
		if (f<3000)
		{
			//throw new EmpException();
			throw new RuntimeException();
		}
	}
}
