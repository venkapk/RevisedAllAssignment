package com.capgemini.lab7_3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.eis.bean.Employee;
import com.capgemini.eis.service.Service;

public class EmployeeServiceImp {
	static HashMap<String, Employee> list = new HashMap<String,Employee>();

	public static void addEmployee(Employee emp) 
	{
		
		list.put(emp.getInsuranceScheme(), emp);
	}
	public static boolean deleteEmployee(String id)
	{
		if(list.containsKey(id)) 
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	public static void dispInsuranceSchemeEmp() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the insurance scheme eg. Scheme A/Scheme B/Scheme C");
		String insurance = sc.nextLine();
		System.out.println(list.get(insurance));
	}
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of employee details you want to enter");
		int num = sc.nextInt();
		Employee emp[] = new Employee[num];
		for (int i=0;i<num;i++) {
			emp[i] = new Employee();
			System.out.println("Enter Employee ID: ");
			int id = sc.nextInt();
			System.out.println("Enter Employee Name: ");
			String name = sc.next();
			System.out.println("Enter Employee Salary: ");
			Double sal = sc.nextDouble();
			emp[i].setId(id);
			emp[i].setName(name);
			emp[i].setSalary(sal);
			Service s = new Service();
			s.method1(emp[i]);
			s.method2(emp[i]);
		}
		//adding all emp objects to hashmap
		for (int i=0;i<num;i++) 
		{
			list.put(emp[i].getInsuranceScheme(), emp[i]);
		}
		//if user wants to add another emp
		Employee anotherUser = new Employee();
		System.out.println("Enter another user:");
		System.out.println("Enter Employee ID: ");
		int iD = sc.nextInt();
		System.out.println("Enter Employee Name: ");
		String name = sc.next();
		System.out.println("Enter Employee Salary: ");
		Double sal = sc.nextDouble();
		anotherUser.setId(iD);
		anotherUser.setName(name);
		anotherUser.setSalary(sal);
		Service s = new Service();
		s.method1(anotherUser);
		s.method2(anotherUser);
		addEmployee(anotherUser);
		System.out.println();
		//accept insurance scheme from user
		Set<Entry<String, Employee>> hashSet=list.entrySet();
        for(Entry entry:hashSet ) {

            System.out.println("Key="+entry.getKey()+", Value="+entry.getValue());
        }
		dispInsuranceSchemeEmp();
		sc.nextLine();
		//delete the emp
		System.out.println();
		System.out.println("Enter the Scheme of the person whose details should be deleted");
		String input = sc.nextLine(); 
		System.out.println(input);
		boolean boo = deleteEmployee(input);
		if (boo) 
		{
			list.remove(input);
			System.out.println("Deleted");
		}
		else 
		{
			System.out.println("Not present");
		}
		//after sorting
		System.out.println("After sorting:");
		Set<Entry<String, Employee>> set = list.entrySet();
        List<Entry<String, Employee>> list1 = new ArrayList<Entry<String, Employee>>(set);
        Collections.sort( list1, new Comparator<Map.Entry<String, Employee>>()
        {
           // public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
            //{
             //   return (o2.getValue()).compareTo( o1.getValue() );
           // }

			@Override
			public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
				return (o2.getValue()).compareTo( o1.getValue() );
			}
        } );
        for(Map.Entry<String, Employee> entry:list1){
            System.out.println(entry.getKey()+" ==== "+entry.getValue());
        }
	}
}