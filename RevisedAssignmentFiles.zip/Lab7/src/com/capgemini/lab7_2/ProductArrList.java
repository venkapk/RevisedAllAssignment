package com.capgemini.lab7_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class ProductArrList 
{
	ArrayList<String> product = new ArrayList<String>();
	Scanner sc=new Scanner(System.in);
	public void sortProduct()
	{
		
		System.out.println("Enter the no. of products");
		int num = sc.nextInt();
		System.out.println("\nEnter the products");
		for (int i=0;i <= num; i++) 
		{
			String prod = sc.nextLine();
			product.add(prod);
		}
		Collections.sort(product);
		
		for(String pr:product) {
			System.out.println(pr);
		}
	}
}
