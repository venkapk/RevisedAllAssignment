package com.capgemini.lab7_2;

import java.util.Scanner;

public class ProductMain 
{

	private static Scanner sc;

	public static void main(String[] args) 
	{
		for(;;)
		{
		ProductArrList ProductList=new ProductArrList();
		ProductList.sortProduct();
		}
	}

}
