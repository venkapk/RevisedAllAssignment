package com.cg.synch.demos;

public class Resource 
{
	private int data;
	boolean dataAvailable=false;
	synchronized void insert(int data)
	{
		if(dataAvailable)
		{
			try 
			{
				wait();
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
		else
		{
			this.data=data;
			dataAvailable=true;
			System.out.println("Inserted.."+data);
			notify();
		}
	}
	synchronized int retrieve()
	{
		if(!dataAvailable)
		{
			try 
			{
				wait();
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
		dataAvailable=false;
		System.out.println("Retrieved.."+data);
		notify();
		return this.data;
	}
}
