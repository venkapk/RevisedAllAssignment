package com.capgemini.lab9_2;

public enum Gender {
      M, F,
}