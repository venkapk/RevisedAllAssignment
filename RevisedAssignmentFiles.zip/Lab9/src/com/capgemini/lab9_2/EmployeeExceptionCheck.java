package com.capgemini.lab9_2;

import org.junit.Test;

import com.capgemini.eis.bean.Employee;
import com.capgemini.eis.exception.*;

public class EmployeeExceptionCheck 
{
	EmployeeException employeeExcep = new EmployeeException();
	Employee e1 = null;
	
	@Test (expected=RuntimeException.class)
	public void testNullsInName()
		{
			EmployeeException.checkEmp(1500);		
		}
}
