package com.capgemini.lab9_2;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.lesson9.Gender;
import com.capgemini.lesson9.Person;

public class PersonTestCase 
{
	private static Gender gender;
	static Person p1 = new Person();
	@BeforeClass
	public static void setUp() {
		System.out.println("setUp is called once");
		p1.setFirstName("Prasad");
		p1.setLastName("Kulkarni");
		String gen="M";
		gender=Gender.valueOf(gen);
		p1.setGender(gender);
	}
	@Test
	public void testFirstName() {
		Assert.assertEquals("Prasad",p1.getFirstName());
	}
	@Test
	public void testLastName() {
		Assert.assertEquals("Kulkarni",p1.getLastName());
	}
	@Test
	public void testGender() {
		Gender s = p1.getGender();
		String gen="M";
		gender=Gender.valueOf(gen);
		Assert.assertEquals(gender,s);
	}
	@Test
	public void testFullName() {
		Assert.assertEquals("Prasad Kulkarni",p1.getFullName());
	}
}
