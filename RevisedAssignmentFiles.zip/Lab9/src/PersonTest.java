import org.junit.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class PersonTest {

	@Test
	public void testGetFullName()
	{
		System.out.println("from TestPerson");
		Person per = new Person("John","Snow");
		assertEquals("John Snow",per.getFullName());
	}
	
	@Test (expected=IllegalArgumentException.class)
	public void testNullsInName()
		{
		System.out.println("Testing exceptions");
		Person per1 = new Person(null,null);	
	}

}
