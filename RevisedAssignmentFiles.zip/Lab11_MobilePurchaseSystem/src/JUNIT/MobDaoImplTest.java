package JUNIT;

import java.util.ArrayList;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.AllServiceImp;

import junit.framework.Assert;

public class MobDaoImplTest {
	static AllServiceImp ASI= null;
	static Mobile mob1 = null;
	@BeforeClass
	public static void setUp() {
		ASI = new AllServiceImp();
		mob1 = new Mobile(1050,"Oppo_1 F2",1000,"17");
		System.out.println("setUp is called");
	}
	@Test
	public void insMobTest() throws MobileException {
		int done = ASI.addMob(mob1);
				Assert.assertEquals(1, done);
	
	}
	@Test
	public void serMobTest() throws MobileException {
		int done = ASI.searchMob(15000);
		Assert.assertEquals(2, done);
	}
}
