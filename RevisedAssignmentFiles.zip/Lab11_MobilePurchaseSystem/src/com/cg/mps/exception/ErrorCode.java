package com.cg.mps.exception;

public class ErrorCode {

}
