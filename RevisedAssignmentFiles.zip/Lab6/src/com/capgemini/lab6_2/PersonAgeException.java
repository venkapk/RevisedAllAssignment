package com.capgemini.lab6_2;

class AgeException extends Exception 
{
	public AgeException() 
	{
		System.out.println("Asdf");
	}
	public String toString() 
	{
		return "Age is above 15.";
	}


}

public class PersonAgeException 
{
	static void checkAge(int f) throws AgeException  
	{
		if (f>15) 
		{
			throw new AgeException();
		}
	}
	
	public static void main(String[] args) 
	{
		Person p1=new Person("Prasad","Kulkarni",'M',"01/01/2010");
		try 
		{
			checkAge(p1.getAge());
		}
		catch(AgeException e) 
		{
			System.out.println(e);
		}
	}

}
