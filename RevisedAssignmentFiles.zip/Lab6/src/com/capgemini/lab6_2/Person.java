package com.capgemini.lab6_2;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Person 
{
	String firstName;
	String lastName;
	char gender;
	String dob;
	int age;
	
	public Person() 
	{
		super();
	}
	
	public Person(String firstName, String lastName, char gender, String dob) 
	{
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dob = dob;
	}

	public String getFirstName() 
	{
		return firstName;
	}
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	public String getLastName() 
	{
		return lastName;
	}
	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}
	public String getGender() 
	{
		return String.valueOf(this.gender);
	}
	public void setGender(char gender) 
	{
		this.gender = gender;
	}
	public String getDob() 
	{
		return dob;
	}
	public void setDob(String dob) 
	{
		this.dob = dob;
	}
	public int calculateAge(LocalDate date)
	{
		Period p=date.until(LocalDate.now());
		int age= p.getYears();
		this.age=age;
		return age;
	}
	public String getFullName(String fname,String lname)
	{
		return fname+" "+lname;
	}
	public static void main(String[] args)
	{
		Person p1=new Person("Prasad","Kulkarni",'M',"01/01/2010");
		System.out.println(p1.getFullName(p1.getFirstName(), p1.getLastName()));
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date=LocalDate.parse(p1.getDob(),format);
		int yr=p1.calculateAge(date);
		System.out.println(yr);
	}

	public int getAge() 
	{
		return age;
	}
}
