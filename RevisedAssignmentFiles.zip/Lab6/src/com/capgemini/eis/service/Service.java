package com.capgemini.eis.service;

import com.capgemini.eis.bean.*;

public class Service {
	public interface EmployeeService {

		void dispDetails(Employee e1);

		void schemeDecide(Employee e1);

	}
	public class ImplementEmployeeService implements EmployeeService {
		
		
		public ImplementEmployeeService() {
		}
		@Override
		public void schemeDecide(Employee e1) {
			
			if (e1.getSalary() > 5000 && e1.getSalary() < 20000) {
				e1.setInsuranceScheme("Scheme C");
			}
			else if(e1.getSalary() >=20000  && e1.getSalary() < 40000) {
				e1.setInsuranceScheme("Scheme B");
			}
			else if(e1.getSalary() >=40000) {
				e1.setInsuranceScheme("Scheme A");
			}
			else if(e1.getSalary() < 5000){ 
				e1.setInsuranceScheme("No Scheme");
			}
		}
		@Override
		public void dispDetails(Employee e1) {
			System.out.println("Employee ID: " + e1.getId());
			System.out.println("Employee Name: " + e1.getName());
			System.out.println("Employee Salary: " + e1.getSalary());
			System.out.println("Employee I.S.: " + e1.getInsuranceScheme());
			if (e1.getSalary() > 5000 && e1.getSalary() < 20000) {
				e1.setDesignation("System Associate");
			}
			else if(e1.getSalary() >=20000  && e1.getSalary() < 40000) {
				e1.setDesignation("Programmer");
			}
			else if(e1.getSalary() >=40000) {
				e1.setDesignation("Manager");
			}
			else if(e1.getSalary() < 5000){ 
				e1.setDesignation("Clerk");
			}
			System.out.println("Employee Designation: " + e1.getDesignation());
			
		}
	}
	public void method1(Employee e1) {
		ImplementEmployeeService ies = new ImplementEmployeeService();
		ies.schemeDecide(e1);
	}
	public void method2(Employee e1) {
		ImplementEmployeeService ies = new ImplementEmployeeService();
		ies.dispDetails(e1);
	}
}
