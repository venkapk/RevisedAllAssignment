package com.capgemini.lab8_3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.capgemini.eis.bean.Employee;
import com.capgemini.eis.service.Service;

public class AddingFunctionalities 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of employee details you want to enter");
		int num = sc.nextInt();
		Employee emp[] = new Employee[num];
		for (int i=0;i<num;i++) 
		{
			emp[i] = new Employee();
			System.out.println("Enter Employee ID: ");
			int id = sc.nextInt();
			System.out.println("Enter Employee Name: ");
			String name = sc.next();
			System.out.println("Enter Employee Salary: ");
			Double sal = sc.nextDouble();
			emp[i].setId(id);
			emp[i].setName(name);
			emp[i].setSalary(sal);
			Service s = new Service();
			s.method1(emp[i]);
			s.method2(emp[i]);
		}
		//writing to file
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try 
		{
			fos = new FileOutputStream("EmpObj.obj");
			oos = new ObjectOutputStream(fos);
			for(int i=0;i<num;i++) 
			{
				oos.writeObject(emp[i]);
			}
			System.out.println("Employees e_1 is written in the file");
		} 
		catch (IOException e) 
		{
			
		    e.printStackTrace();		
		}
		//reading from file
		FileInputStream fis= null;
		ObjectInputStream ois = null;
		try
		{
			fis = new FileInputStream("EmpObj.obj");
			ois = new ObjectInputStream(fis);
			for(int i=0;i<num;i++) 
			{
			    Employee ee = (Employee) ois.readObject();
				System.out.println("Employee Info from file: " + ee); 
			}			
		} 
		catch (ClassNotFoundException | IOException e) 
		{
			e.printStackTrace();
		}
	}
}