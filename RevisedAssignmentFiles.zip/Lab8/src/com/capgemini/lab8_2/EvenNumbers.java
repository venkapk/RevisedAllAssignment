package com.capgemini.lab8_2;

import java.io.*;
import java.util.Scanner;

public class EvenNumbers 
{
	public static void main(String[] args) 
	{
		File file = new File("D://Vyankateshprasad_Kulkarni//Lab8//Lab8_2_Numbers");
		FileReader fis = null;
		BufferedReader br = null;
		Scanner sc = null;
		try 
		{
			sc = new Scanner(file);
			String line = sc.nextLine();
			String[] parts = line.split(",");
			for (int i = 0; i < parts.length; i++) 
			{
			    if((Integer.parseInt(parts[i])%2)==0) 
			    {
			    	System.out.println(Integer.parseInt(parts[i]));
			    }
			}	
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

}
