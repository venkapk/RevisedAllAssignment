import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class ContentLab8_1
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Content in file:");
		String data=sc.nextLine();
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		try
		{
		   fos=new FileOutputStream("ContentLab8_1.txt");
		   dos=new DataOutputStream(fos);
		   dos.writeUTF(data);
		   System.out.println("All info written in the file.");
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

}
